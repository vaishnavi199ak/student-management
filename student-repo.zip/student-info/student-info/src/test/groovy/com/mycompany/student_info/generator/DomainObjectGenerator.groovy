package com.mycompany.student_info.generator

class DomainObjectGenerator {
}
